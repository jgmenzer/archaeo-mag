# archaeo-mag
Python code for processing magnetometry data with a focus on depth estimations.

This project aims to provide Python 3 code for standard and more complex data processing techniques for magnetometry data.
The focus is on archaeological data, but the techniques are certainly applicable to other disciplines.
Additionally, project will focus on depth estimation techniques.

The project is in its early stages of development on Github, check back soon for updates.

========
Overview
========

Python 3.8 code for processing magnetometry data with a focus on depth estimations.

* Free software: MIT license

Installation
============